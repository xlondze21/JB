# Delegate Voting Abuse

## Definition
## Affected Protocol Types
## Root Cause
## Threat Model
## Required Conditions
## Attack Flow
## Detection Workflow
## Invariant Violated
## False Positive Checklist
## Common Mitigations
## Related Patterns
