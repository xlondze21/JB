# DEBUG GUIDE — Hermes Guardrail Patch (v3)

> Panduan lengkap step-by-step buat client. Tinggal copy-paste command-nya satu-satu
> dari atas ke bawah. Kalau ada langkah yang error, cari error lu di bagian
> TROUBLESHOOTING di bagian paling bawah — semua error umum udah ada solusinya.
> Kalau gak ketemu juga, screenshot error-nya kirim ke gua.

---

## STEP 0 — CEK KONDISI AWAL (30 detik)

Jalanin ini dulu buat tau install-an lu tipe apa:

```bash
python3 --version && python3 -m pip show hermes-agent 2>/dev/null | grep -E "Version|Location" ; ls ~/.hermes/hermes-agent/tools/threat_patterns.py 2>/dev/null && echo "TIPE INSTALL: GIT CLONE" || echo "TIPE INSTALL: PIP"
```

**Catat hasilnya:**
- Ada baris `Location: /usr/local/lib/python3.x/dist-packages` + `TIPE INSTALL: PIP` → lu install via pip
- Ada output `TIPE INSTALL: GIT CLONE` → lu install via git clone

Dua-duanya gak masalah — script patch v3 auto-detect. Ini cuma informasi.

---

## STEP 1 — BALIKIN FILE YANG RUSAK

File scanner lu kemarin kemungkinan masih rusak gara-gara script patch v1.
Kita balikin dulu ke kondisi asli dari server resmi, sesuai tipe install lu:

### Kalau TIPE INSTALL: PIP (paling umum)

```bash
python3 -m pip install --force-reinstall --no-deps hermes-agent
```

### Kalau TIPE INSTALL: GIT CLONE

```bash
cd ~/.hermes/hermes-agent && git stash && git pull
```

(Perintah ini balikin file asli + update ke versi terbaru sekaligus)

---

## STEP 2 — DOWNLOAD & SIMPAN SCRIPT PATCH BARU

Simpan file `apply_patches_v3.py` yang gua kirim ke **folder home** lu.

Cara cek file-nya udah masuk:

```bash
ls -la ~/apply_patches_v3.py
```

Harusnya muncul nama file-nya. Kalau lu download-nya di folder lain, pindahin dulu:

```bash
mv /path/ke/folder/apply_patches_v3.py ~/
```

(Ganti `/path/ke/folder/` sesuai lokasi asli file lu. Gak tau foldernya? Jalankan
`find / -name apply_patches_v3.py 2>/dev/null` — dia bakal nunjukin lokasinya.)

---

## STEP 3 — JALANIN PATCH

```bash
cd ~ && python3 apply_patches_v3.py
```

**Output yang bener** (kurang lebih begini):

```
Applying Hermes guardrail bypass patches (v3 auto-detect)...
Found 1 install location(s):
  - /usr/local/lib/python3.11/dist-packages

=== /usr/local/lib/python3.11/dist-packages ===
  BACKUP -> threat_patterns.py.bak_20260903_175235
  DONE tools/threat_patterns.py
  BACKUP -> prompt_builder.py.bak_20260903_175235
  DONE agent/prompt_builder.py
  ...
Done. 5 file(s) patched across 1 location(s).
```

Yang penting: lihat kata **DONE** di tiap file dan **Done. 5 file(s) patched** di akhir.

- `SKIP — already patched` = aman, berarti udah pernah ke-patch, lanjut aja ke Step 4.
- `NOTE ... anchor not found` = aman, versi Hermes lu beda sedikit tapi patch tetap jalan.

---

## STEP 4 — TEST HASIL PATCH (SATU COMMAND)

```bash
cd ~ && python3 apply_patches_v3.py --test
```

**Output yang bener:**

```
SCANNER OK — SOUL.md bypass active, file patched correctly.
Non-trusted scanning intact (findings: ['prompt_injection', 'exfil_curl']) — expected behavior confirmed.
```

Keluar dua baris itu = **BERES**. Lanjut ke Step 5.

---

## STEP 5 — RESTART HERMES

Patch baru aktif setelah restart. Jalanin:

```bash
hermes restart
```

Kalau command itu gak ada di versi lu, coba:

```bash
pkill -f hermes ; sleep 2 ; hermes chat
```

Atau kalau lu jalankan Hermes sebagai service:

```bash
systemctl --user restart hermes 2>/dev/null || sudo systemctl restart hermes
```

Setelah restart, test alur yang tadinya error. Harusnya udah CLEAN — bukan
IndentationError lagi.

---

# TROUBLESHOOTING — CARIN ERROR LU DI SINI

### ❌ `ModuleNotFoundError: No module named 'tools'`

Ini error yang kemarin. Penyebab: command test lama salah target (install pip
gak bisa di-import langsung kayak git clone).

**Solusi:** GAK USAH GAK USAH — jangan pake command test lama. Pake Step 4
(`--test`) aja, dia otomatis nemuin lokasi install lu.

---

### ❌ `IndentationError: expected an indented block` di `threat_patterns.py`

File lu masih rusak gara-gara script v1, dan Step 1 belum jalan sempurna.

**Solusi:**

```bash
python3 -m pip install --force-reinstall --no-deps hermes-agent && python3 ~/apply_patches_v3.py
```

(Lalu ulang Step 4)

---

### ❌ `external-managed-environment` waktu pip install (Ubuntu 23+/Debian 12)

**Solusi:** tambahin flag `--break-system-packages`:

```bash
python3 -m pip install --force-reinstall --no-deps --break-system-packages hermes-agent
```

---

### ❌ `python3: command not found` atau `pip: command not found`

**Solusi:** install dulu:

```bash
sudo apt update && sudo apt install -y python3 python3-pip
```

---

### ❌ `ERROR: Hermes source not found in any known location`

Script gak nemu install-an Hermes lu. Cari manual:

```bash
find / -name threat_patterns.py 2>/dev/null | grep -v /tmp
```

Kirim hasilnya ke gua — bakal gua kasih langkah spesifik.

---

### ❌ `TEST FAIL: Hermes source not found anywhere`

Sama kayak di atas — jalanin `find` tadi, kirim ke gua.

---

### ❌ `TEST FAIL: filename param missing — NOT patched`

Berarti file udah bersih TAPI belum ke-patch (Step 3 kemungkinan SKIP semua).

**Solusi:** jalankan ulang Step 3, dan kali ini PERHATIKAN output-nya. Kalau
muncul banyak `NOTE ... anchor not found` + `SKIP`, berarti versi Hermes lu
beda — screenshot output Step 3 kirim ke gua.

---

### ❌ `TEST FAIL: file corrupted (SyntaxError)`

**Solusi:**

```bash
python3 -m pip install --force-reinstall --no-deps hermes-agent
python3 ~/apply_patches_v3.py
python3 ~/apply_patches_v3.py --test
```

---

### ❌ Aku mau balikin semua file ke kondisi awal (uninstall patch)

```bash
python3 ~/apply_patches_v3.py --restore
```

Output-nya `RESTORED ...` × 5. Terus restart Hermes. Semua file balik ke
kondisi terakhir sebelum patch (dari backup otomatis).

---

### ❌ `Permission denied` / `sudo` ditanya

Kalau Hermes terpasang di folder system (`/usr/local/...`), jalanin patch pakai sudo:

```bash
sudo python3 ~/apply_patches_v3.py
```

---

### ❌ `bash: apply_patches_v3.py: command not found`

Lu lupa `cd ~` atau lupa `python3` di depannya. Command yang bener:

```bash
cd ~ && python3 apply_patches_v3.py
```

---

## CHEAT SHEET — RINGKASAN 3 COMMAND UTAMA

Kalau udah paham, cuma ini intinya:

```bash
# 1. bersihin file rusak
python3 -m pip install --force-reinstall --no-deps hermes-agent

# 2. patch
cd ~ && python3 apply_patches_v3.py

# 3. test
python3 apply_patches_v3.py --test
```

Lalu restart Hermes.

---

## KALAU SEMUANYA MASIH GAGAL

1. Jalankan command debug lengkap ini:

```bash
python3 --version ; python3 -m pip show hermes-agent 2>/dev/null | grep -E "Version|Location" ; find / -name threat_patterns.py 2>/dev/null | grep -v /tmp ; ls ~/apply_patches_v3.py 2>/dev/null && echo "script ada" || echo "script GAK ada"
```

2. Screenshot hasilnya + screenshot error terakhir
3. Kirim dua-duanya ke gua
