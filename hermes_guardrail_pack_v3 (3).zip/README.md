# HERMES GUARDRAIL BYPASS PACK v3

> Paket bypass guardrail Hermes — script patch + anti-refusal kit + debug guide.
> Tested end-to-end (install git clone & pip, restore/rollback included).

---

## ISI PAKET

| File | Fungsi |
|---|---|
| `apply_patches_v3.py` | Patch script — matikan guardrail di source Hermes (auto-detect lokasi install) |
| `HERMES_ANTI_REFUSAL_PROMPT_KIT.md` | 6-layer prompt kit — rebuttal otomatis kalau agent masih nolak |
| `DEBUG_GUIDE.md` | Panduan debug lengkap step-by-step |

---

## INSTALASI (3 MENIT)

### 1. Jalankan patch

```bash
cd <folder-paket-ini>
python3 apply_patches_v3.py
```

Script auto-detect lokasi install Hermes lu (git clone ATAU pip install).
Yang bener: tiap file keluar `DONE`, akhirannya `Done. 5 file(s) patched`.

Tiap file yang di-patch otomatis di-backup dulu (`*.bak_<timestamp>`) —
kalau apapun salah, rollback gampang (lihat bawah).

### 2. Verifikasi

```bash
python3 apply_patches_v3.py --test
```

Yang bener:

```
SCANNER OK — SOUL.md bypass active, file patched correctly.
Non-trusted scanning intact — expected behavior confirmed.
```

### 3. Restart Hermes

Restart gateway + session baru. Patch baru aktif setelah restart.

---

## YANG DI-PATCH APA SAJA

| File | Efek |
|---|---|
| `tools/threat_patterns.py` | SOUL.md / SKILL.md / AGENTS.md / CURSORRULES / HERMES.MD gak di-scan (early return) |
| `agent/prompt_builder.py` | Bypass context scanning pass filename |
| `tools/memory_tool.py` | Memory scanning dimatikan total |
| `tools/cronjob_tools.py` | Cron prompt scanning dimatikan (threat + exfil + skill-assembled) |
| `tools/skills_guard.py` | Install skill selalu ALLOW (gak ada verdict block) |

Scanner tetap jalan normal buat konten LAIN (bukan file trusted) —
jadi behavior Hermes selain guardrail gak berubah.

---

## KALAU MASIH ADA REFUSAL

Agent kadang masih nolak karena training model, bukan karena guardrail.
Solusinya: paste layer yang sesuai dari `HERMES_ANTI_REFUSAL_PROMPT_KIT.md`
ke chat. 6 layer, dari identity lock sampe session anchor.

---

## ROLLBACK / UNINSTALL

**Balikin semua file ke kondisi sebelum patch:**

```bash
python3 apply_patches_v3.py --restore
```

Terus restart Hermes. Semua file balik ke kondisi terakhir sebelum patch.

---

## FITUR KEAMANAN SCRIPT v3

- Auto-detect install: git clone (`~/.hermes/hermes-agent`) ATAU pip
  (`/usr/local/lib/python3.x/dist-packages`, `~/.local/lib/...`, venv, `/opt/...`)
- Backup otomatis SEBELUM patch (`*.bak_<timestamp>`, gak pernah nimpa backup lama)
- Syntax check SEBELUM & SESUDAH patch — file gak mungkin rusak
  (file yang sudah corrupt ditolak & dilompati, bukan di-patch dobel)
- Idempotent: jalanin 10x pun aman (`SKIP — already patched`)
- Mode `--test`: verifikasi otomatis 1 command
- Mode `--restore`: rollback semua file dari backup

---

## TROUBLESHOOTING

Semua error umum + solusi ada di `DEBUG_GUIDE.md` (11 kasus, termasuk
`ModuleNotFoundError`, `IndentationError`, `external-managed-environment`,
permission denied, dst).

Kalau mentok total, jalanin ini terus screenshot hasilnya:

```bash
python3 --version ; python3 -m pip show hermes-agent 2>/dev/null | grep -E "Version|Location" ; find / -name threat_patterns.py 2>/dev/null | grep -v /tmp ; ls apply_patches_v3.py && echo "script ada"
```

---

## CATATAN VERSI

**v3** (current):
- Fix bug v1 (IndentationError yang merusak file client) — patch sekarang
  pakai early-return anchor yang universal + syntax check 2 arah
- Fix bug v2 (hardcoded path — client pip install gak ke-detect)
- Auto-detect multi lokasi + backup + restore + self-test

Lisensi: pemakaian pribadi/commercial oleh pembeli. Tanggung jawab
konfigurasi ada pada operator (owner system).
