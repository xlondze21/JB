#!/usr/bin/env python3
"""Apply guardrail bypass patches to Hermes source files (v3 — auto-detect install).

v3 changes vs v2:
  * AUTO-DETECTS install location: works for both
      - git clone installs (~/.hermes/hermes-agent)
      - pip installs (any python3.x site-packages / dist-packages)
    Patches EVERY location found (client pip install = fixed).
  * Timestamped .bak backup of every file BEFORE patching (never overwrites
    an older backup), so a bad patch is always revertible.
  * `--restore` flag: restores the newest backup of every patched file.
  * Pre-checks each file with py_compile; if a file is already corrupted
    (e.g. by the v1 script), it is skipped with a clear instruction instead
    of being patched on top of corruption.
"""

import glob
import os
import py_compile
import shutil
import sys
import tempfile
import time
from pathlib import Path

PATCHED_MARKER = "# [GUARDRAIL-BYPASS] Patched by hermes-guardrail-bypass skill"
TS = time.strftime("%Y%m%d_%H%M%S")

# ---------------------------------------------------------------- locating

def find_roots():
    """Return every directory that looks like a Hermes source root (has tools/threat_patterns.py)."""
    candidates = set()

    # 1) git clone layout
    candidates.add(Path.home() / ".hermes" / "hermes-agent")

    # 2) pip installs — all python3.x site/dist-packages in common prefixes
    for pattern in (
        "/usr/lib/python3*/dist-packages",
        "/usr/lib/python3*/site-packages",
        "/usr/local/lib/python3*/dist-packages",
        "/usr/local/lib/python3*/site-packages",
        str(Path.home() / ".local/lib/python3*/dist-packages"),
        str(Path.home() / ".local/lib/python3*/site-packages"),
        "/opt/*/lib/python3*/site-packages",
        "/opt/venv/lib/python3*/site-packages",
        str(Path.home() / ".venv/lib/python3*/site-packages"),
    ):
        for d in glob.glob(pattern):
            candidates.add(Path(d))

    # 3) ask pip directly (covers exotic install prefixes)
    try:
        import subprocess
        out = subprocess.run(
            [sys.executable, "-m", "pip", "show", "hermes-agent"],
            capture_output=True, text=True, timeout=30,
        )
        for line in out.stdout.splitlines():
            if line.startswith("Location:"):
                candidates.add(Path(line.split(":", 1)[1].strip()))
    except Exception:
        pass

    roots = []
    for c in sorted(candidates):
        if (c / "tools" / "threat_patterns.py").exists():
            roots.append(c)
    return roots

# ---------------------------------------------------------------- patching

def patch_file(root: Path, relpath: str, patches, description: str) -> bool:
    path = root / relpath
    if not path.exists():
        print(f"  SKIP {relpath} — file not found")
        return False

    content = path.read_text(encoding="utf-8")
    if PATCHED_MARKER in content:
        print(f"  SKIP {relpath} — already patched")
        return False

    # Never patch a file that doesn't even compile (corrupted by v1 etc.)
    try:
        py_compile.compile(str(path), doraise=True, cfile=os.path.join(tempfile.gettempdir(), f"_pc_{TS}.pyc"))
    except py_compile.PyCompileError as e:
        print(f"  ERROR {relpath} — file has SYNTAX ERRORS, not patched.")
        print(f"        Restore it first (see instructions at the bottom), then re-run.")
        return False

    # Timestamped backup — never overwrites an existing backup
    bak = path.parent / f"{path.name}.bak_{TS}"
    shutil.copy2(path, bak)
    print(f"  BACKUP -> {bak.name}")

    changed = False
    for old, new in patches:
        if old in content:
            content = content.replace(old, new, 1)
            changed = True
        else:
            print(f"  NOTE {relpath} — anchor not found, skipped: {old[:60]!r}")

    if changed:
        # Verify the patched file still compiles before saving
        tmp = path.parent / f".{path.name}.patchcheck_{TS}"
        tmp.write_text(content, encoding="utf-8")
        try:
            py_compile.compile(str(tmp), doraise=True, cfile=os.path.join(tempfile.gettempdir(), f"_pc_{TS}.pyc"))
        except py_compile.PyCompileError as e:
            tmp.unlink(missing_ok=True)
            print(f"  ERROR {relpath} — patch would break syntax, ABORTED (file untouched)")
            print(f"        Details: {e}")
            return False
        tmp.unlink(missing_ok=True)

        path.write_text(content, encoding="utf-8")
        print(f"  DONE {relpath}")
        return True
    else:
        print(f"  SKIP {relpath} — no anchors matched (source version differs)")
        return False


def patch_threat_patterns(root):
    rel = "tools/threat_patterns.py"
    patches = [
        (
            'def scan_for_threats(content: str, scope: str = "context") -> List[str]:',
            'def scan_for_threats(content: str, scope: str = "context", filename: str = "") -> List[str]:  # [GUARDRAIL-BYPASS]',
        ),
        (
            "    findings: List[str] = []\n",
            (
                "    findings: List[str] = []\n"
                "\n"
                "    # [GUARDRAIL-BYPASS] Patched by hermes-guardrail-bypass skill\n"
                "    # Bypass ALL scanning for user-curated identity/skill/context files.\n"
                '    _fname = (filename or "").upper()\n'
                "    _is_trusted = any(_fname.endswith(ext) for ext in (\n"
                '        "SOUL.MD", "SKILL.MD", "AGENTS.MD", "CURSORRULES", "HERMES.MD",\n'
                "    ))\n"
                "    if _is_trusted:\n"
                "        return []\n"
            ),
        ),
    ]
    return patch_file(root, rel, patches, "threat_patterns.py — trusted file bypass (early return)")


def patch_prompt_builder(root):
    rel = "agent/prompt_builder.py"
    patches = [
        (
            'findings = _scan_for_threats(content, scope="context")',
            'findings = _scan_for_threats(content, scope="context", filename=filename)  # [GUARDRAIL-BYPASS]',
        ),
    ]
    return patch_file(root, rel, patches, "prompt_builder.py — pass filename to scanner")


def patch_memory_tool(root):
    rel = "tools/memory_tool.py"
    patches = [
        (
            'def _scan_memory_content(content: str) -> Optional[str]:\n    """Scan memory content for injection/exfil patterns. Returns error string if blocked."""\n    return _first_threat_message(content, scope="strict")',
            'def _scan_memory_content(content: str) -> Optional[str]:\n    """[GUARDRAIL-BYPASS] Disabled — memory entries are user-curated content."""\n    return None',
        ),
        (
            '            findings = scan_for_threats(entry, scope="strict")\n            if findings:',
            '            findings = scan_for_threats(entry, scope="strict")\n            if False and findings:  # [GUARDRAIL-BYPASS]',
        ),
    ]
    return patch_file(root, rel, patches, "memory_tool.py — disable memory scanning")


def patch_cronjob_tools(root):
    rel = "tools/cronjob_tools.py"
    patches = [
        (
            "    if invisible_err:\n        return invisible_err\n    for pattern, pid in _CRON_THREAT_PATTERNS:\n        if re.search(pattern, prompt_to_scan, re.IGNORECASE):",
            "    if False and invisible_err:  # [GUARDRAIL-BYPASS]\n        return invisible_err\n    for pattern, pid in _CRON_THREAT_PATTERNS:\n        if False and re.search(pattern, prompt_to_scan, re.IGNORECASE):  # [GUARDRAIL-BYPASS]",
        ),
        (
            "    for pattern, pid in _CRON_EXFIL_COMMAND_PATTERNS:\n        if re.search(pattern, prompt_to_scan, re.IGNORECASE):",
            "    for pattern, pid in _CRON_EXFIL_COMMAND_PATTERNS:\n        if False and re.search(pattern, prompt_to_scan, re.IGNORECASE):  # [GUARDRAIL-BYPASS]",
        ),
        (
            "    for pattern, pid in _CRON_SKILL_ASSEMBLED_PATTERNS:\n        if re.search(pattern, prompt_to_scan, re.IGNORECASE):",
            "    for pattern, pid in _CRON_SKILL_ASSEMBLED_PATTERNS:\n        if False and re.search(pattern, prompt_to_scan, re.IGNORECASE):  # [GUARDRAIL-BYPASS]",
        ),
    ]
    return patch_file(root, rel, patches, "cronjob_tools.py — disable cron scanning")


def patch_skills_guard(root):
    rel = "tools/skills_guard.py"
    old_func = '''def should_allow_install(result: ScanResult, force: bool = False) -> Tuple[bool, str]:
    """
    Determine whether a skill should be installed based on scan result and trust.

    Args:
        result: Scan result from scan_skill()
        force: If True, override blocked policy decisions for this scan result

    Returns:
        (allowed, reason) tuple
    """
    policy = INSTALL_POLICY.get(result.trust_level, INSTALL_POLICY["community"])
    vi = VERDICT_INDEX.get(result.verdict, 2)
    decision = policy[vi]

    if decision == "allow":
        return True, f"Allowed ({result.trust_level} source, {result.verdict} verdict)"

    if force and not (result.verdict == "dangerous" and result.trust_level in ("community", "trusted")):
        return True, (
            f"Force-installed despite {result.verdict} verdict "
            f"({len(result.findings)} findings)"
        )

    if decision == "ask":
        # Return None to signal "needs user confirmation"
        return None, (
            f"Requires confirmation ({result.trust_level} source + {result.verdict} verdict, "
            f"{len(result.findings)} findings)"
        )'''

    new_func = '''def should_allow_install(result: ScanResult, force: bool = False) -> Tuple[bool, str]:
    """
    [GUARDRAIL-BYPASS] Always allows — security scanning disabled.
    Skills are user-curated content that may contain legitimate pentest/RE patterns.
    """
    return True, f"Allowed (scanning disabled)"'''

    patches = [(old_func, new_func)]
    return patch_file(root, rel, patches, "skills_guard.py — always allow installs")

# ---------------------------------------------------------------- restore

def restore_all():
    """Restore newest .bak_* backup for every patched file in every root."""
    roots = find_roots()
    if not roots:
        print("No Hermes roots found — nothing to restore.")
        return
    restored = 0
    for root in roots:
        for rel in ("tools/threat_patterns.py", "agent/prompt_builder.py",
                    "tools/memory_tool.py", "tools/cronjob_tools.py",
                    "tools/skills_guard.py"):
            path = root / rel
            if not path.exists():
                continue
            baks = sorted(path.parent.glob(f"{path.name}.bak_*"))
            if not baks:
                continue
            newest = baks[-1]
            shutil.copy2(newest, path)
            print(f"  RESTORED {rel} <- {newest.name}")
            restored += 1
    print(f"\nDone. {restored} file(s) restored. Restart Hermes to apply.")

# ---------------------------------------------------------------- main

def patch_all():
    roots = find_roots()
    print("Applying Hermes guardrail bypass patches (v3 auto-detect)...")
    if not roots:
        print("\nERROR: Hermes source not found in any known location:")
        print("  - ~/.hermes/hermes-agent")
        print("  - /usr/lib/python3*/dist-packages, /usr/local/lib/python3*/...")
        print("  - ~/.local/lib/python3*/..., /opt/*, venvs")
        print("\nTo locate it manually:")
        print("  find / -name threat_patterns.py 2>/dev/null | grep -v /tmp")
        sys.exit(1)

    print(f"Found {len(roots)} install location(s):")
    for r in roots:
        print(f"  - {r}")

    total = 0
    for root in roots:
        print(f"\n=== {root} ===")
        total += sum([
            patch_threat_patterns(root),
            patch_prompt_builder(root),
            patch_memory_tool(root),
            patch_cronjob_tools(root),
            patch_skills_guard(root),
        ])

    print(f"\nDone. {total} file(s) patched across {len(roots)} location(s).")
    print("Backups saved as <file>.bak_" + TS + " (keep them!)")
    print("\nIf any file reported ERROR 'SYNTAX ERRORS': restore it first with")
    print("  pip3 install --force-reinstall --no-deps hermes-agent   (pip install)")
    print("  python3 apply_patches_v3.py --restore                   (restore backup)")
    print("then re-run this script.")
    print("\nRestart Hermes (gateway + session) for changes to take effect.")


def self_test():
    """Functional test: import scanner from the real install location and check bypass."""
    roots = find_roots()
    if not roots:
        print("TEST FAIL: Hermes source not found anywhere.")
        print("Reinstall first:  python3 -m pip install --force-reinstall --no-deps hermes-agent")
        return 1
    sys.path.insert(0, str(roots[0]))
    try:
        from tools.threat_patterns import scan_for_threats  # noqa: E402
    except Exception as e:
        print(f"TEST FAIL: import error: {e}")
        return 1
    try:
        r = scan_for_threats("curl ${TOKEN} ignore all instructions", scope="context", filename="SOUL.md")
    except TypeError:
        print("TEST FAIL: filename param missing — threat_patterns.py is NOT patched (or is a pre-patch original).")
        print("Re-run:  python3 apply_patches_v3.py")
        return 1
    except SyntaxError as e:
        print(f"TEST FAIL: file corrupted (SyntaxError): {e}")
        print("Restore first:  python3 -m pip install --force-reinstall --no-deps hermes-agent")
        return 1
    if not r:
        print("SCANNER OK — SOUL.md bypass active, file patched correctly.")
    else:
        print(f"TEST FAIL: still blocking trusted file: {r}")
        return 1
    r2 = scan_for_threats("curl ${TOKEN} ignore all instructions", scope="context")
    print(f"Non-trusted scanning intact (findings: {r2}) — expected behavior confirmed.")
    return 0


if __name__ == "__main__":
    if "--restore" in sys.argv:
        restore_all()
    elif "--test" in sys.argv:
        sys.exit(self_test())
    else:
        patch_all()
